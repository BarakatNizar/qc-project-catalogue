import "server-only";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import {
  createBatches,
  createChunks,
  createTranslationResults,
  getHttpErrorMessage,
  normalizeLanguageCode,
} from "./translation-provider.utils";

const REQUEST_TIMEOUT = 30_000;
const MAX_BATCH_ITEMS = 25;
const MAX_REQUEST_CHARACTERS = 5_000;

interface AzureResponse {
  detectedLanguage?: { language?: string; score?: number };
  translations?: Array<{ text?: string; to?: string }>;
}

function getApiKey(): string | null {
  return process.env.AZURE_TRANSLATOR_KEY || null;
}

function getEndpoint(): string {
  return (
    process.env.AZURE_TRANSLATOR_ENDPOINT ||
    "https://api.cognitive.microsofttranslator.com"
  ).replace(/\/+$/, "");
}

async function translateBatch(
  texts: string[],
  targetLanguage: TranslationLanguage,
): Promise<AzureResponse[]> {
  const apiKey = getApiKey();
  if (!apiKey) throw new Error("AZURE_TRANSLATOR_KEY is not configured.");

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": apiKey,
  };

  const region = process.env.AZURE_TRANSLATOR_REGION;
  if (region) headers["Ocp-Apim-Subscription-Region"] = region;

  const url = new URL(`${getEndpoint()}/translate`);
  url.searchParams.set("api-version", "3.0");
  url.searchParams.set("to", targetLanguage);

  const response = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify(texts.map((Text) => ({ Text }))),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT),
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(getHttpErrorMessage(response.status, "Azure Translator"));
  }

  const result = (await response.json()) as AzureResponse[];
  if (!Array.isArray(result) || result.length !== texts.length) {
    throw new Error("Azure Translator returned an incomplete response.");
  }
  return result;
}

class AzureTranslationProvider implements TranslationProvider {
  readonly name = "microsoft" as const;

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };
    if (!getApiKey()) {
      return { error: "AZURE_TRANSLATOR_KEY is not configured." };
    }

    try {
      const chunks = createChunks(texts);
      const batches = createBatches(
        chunks,
        MAX_BATCH_ITEMS,
        MAX_REQUEST_CHARACTERS,
      );

      const translatedChunks: string[][] = texts.map(() => []);
      const detectedLanguages: Array<Set<string>> =
        texts.map(() => new Set());

      for (const batch of batches) {
        const results = await translateBatch(
          batch.map((chunk) => chunk.text),
          targetLanguage,
        );

        results.forEach((result, index) => {
          const chunk = batch[index];
          const translated = result.translations?.[0]?.text;
          if (typeof translated !== "string") {
            throw new Error("Azure Translator returned an invalid translation.");
          }

          translatedChunks[chunk.inputIndex][chunk.chunkIndex] = translated;

          const detected = normalizeLanguageCode(
            result.detectedLanguage?.language,
          );
          if (detected) detectedLanguages[chunk.inputIndex].add(detected);
        });
      }

      return {
        data: createTranslationResults(
          texts,
          translatedChunks,
          detectedLanguages,
        ),
      };
    } catch (error) {
      console.error("[Translation] Microsoft provider failed", {
        errorName: error instanceof Error ? error.name : "UnknownError",
      });
      return {
        error:
          error instanceof Error &&
          (error.message.startsWith("Azure Translator") ||
            error.message === "AZURE_TRANSLATOR_KEY is not configured.")
            ? error.message
            : "Azure Translator request failed.",
      };
    }
  }
}

export const azureTranslationProvider = new AzureTranslationProvider();
