//@/modules/translation/providers/base-translation.provider.ts"

import "server-only";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderName,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import { googleTranslationProvider } from "./google-translation.provider";
import { azureTranslationProvider } from "./azure-translation.provider";
import { deeplTranslationProvider } from "./deepl-translation.provider";
import { libreTranslateProvider } from "./libre-translate.provider";
import { lingvaTranslationProvider } from "./lingva-translation.provider";
import { localAITranslateProvider } from "./local-ai-translation.provider";
//missing openrouterAITranslateProvider.

export interface BaseTranslationProviderOptions {
  /**
   * Override the default order for testing or special deployments.
   */
  providers?: TranslationProvider[];

  /** Called when a provider successfully translates the complete request. */
  onSuccess?: (provider: TranslationProviderName) => void;

  /** Called when a provider fails and the next provider will be attempted. */
  onFallback?: (
    failedProvider: TranslationProviderName,
    error: string,
    nextProvider: TranslationProviderName,
  ) => void;
}

const DEFAULT_PROVIDERS: TranslationProvider[] = [
  localAITranslateProvider,
  libreTranslateProvider,
  lingvaTranslationProvider,
  googleTranslationProvider,
  azureTranslationProvider,
  deeplTranslationProvider,
];

export class BaseTranslationProvider {
  private readonly providers: TranslationProvider[];
  private readonly options: BaseTranslationProviderOptions;

  constructor(options: BaseTranslationProviderOptions = {}) {
    this.providers = options.providers ?? DEFAULT_PROVIDERS;
    this.options = options;

    if (this.providers.length === 0) {
      throw new Error("At least one translation provider is required.");
    }
  }

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };

    const failures: Array<{
      provider: TranslationProviderName;
      error: string;
    }> = [];

    for (let index = 0; index < this.providers.length; index += 1) {
      const provider = this.providers[index];

      try {
        const result = await provider.translateMany(texts, targetLanguage);

        if ("data" in result) {
          try {
            this.options.onSuccess?.(provider.name);
          } catch (callbackError) {
            console.error("[Translation] onSuccess callback failed", {
              errorName:
                callbackError instanceof Error
                  ? callbackError.name
                  : "UnknownError",
            });
          }

          if (index > 0) {
            console.info(
              `[Translation] Fallback succeeded using ${provider.name}.`,
            );
          }

          return {
            data: result.data,
            provider: provider.name,
          };
        }

        failures.push({
          provider: provider.name,
          error: result.error,
        });
      } catch (error) {
        failures.push({
          provider: provider.name,
          error: error instanceof Error ? error.message : "Unknown error.",
        });
      }

      const nextProvider = this.providers[index + 1];

      if (nextProvider) {
        const failure = failures[failures.length - 1];

        console.warn(
          `[Translation] ${provider.name} failed; trying ${nextProvider.name}.`,
          { error: failure.error },
        );

        try {
          this.options.onFallback?.(
            provider.name,
            failure.error,
            nextProvider.name,
          );
        } catch (callbackError) {
          console.error("[Translation] onFallback callback failed", {
            errorName:
              callbackError instanceof Error
                ? callbackError.name
                : "UnknownError",
          });
        }
      }
    }

    const summary = failures
      .map(({ provider, error }) => `${provider}: ${error}`)
      .join(" | ");

    console.error("[Translation] All providers failed.", { failures });

    return {
      error: `All translation providers failed. ${summary}`,
    };
  }
}

export const baseTranslationProvider = new BaseTranslationProvider();
