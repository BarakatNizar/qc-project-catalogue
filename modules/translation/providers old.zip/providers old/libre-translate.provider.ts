import "server-only";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import {
  createChunks,
  createTranslationResults,
  getHttpErrorMessage,
  normalizeLanguageCode,
  type TextChunk,
} from "./translation-provider.utils";

const REQUEST_TIMEOUT = 300_000;
const CONCURRENCY = 5;

interface LibreTranslateResponse {
  translatedText?: string;
  detectedLanguage?: { language?: string; confidence?: number };
}

function getBaseUrl(): string {
  return (
    process.env.LIBRETRANSLATE_BASE_URL || "https://libretranslate.com"
  ).replace(/\/+$/, "");
}

async function translateChunk(
  chunk: TextChunk,
  targetLanguage: TranslationLanguage,
): Promise<{ translatedText: string; detectedLanguage: string | null }> {
  const apiKey = process.env.LIBRETRANSLATE_API_KEY;
  const response = await fetch(`${getBaseUrl()}/translate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      q: chunk.text,
      source: "auto",
      target: targetLanguage,
      format: "text",
      ...(apiKey ? { api_key: apiKey } : {}),
    }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT),
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(getHttpErrorMessage(response.status, "LibreTranslate"));
  }

  const result = (await response.json()) as LibreTranslateResponse;
  if (typeof result.translatedText !== "string") {
    throw new Error("LibreTranslate returned an invalid translation response.");
  }

  return {
    translatedText: result.translatedText,
    detectedLanguage: normalizeLanguageCode(
      result.detectedLanguage?.language,
    ),
  };
}

class LibreTranslateProvider implements TranslationProvider {
  readonly name = "libretranslate" as const;

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };

    try {
      const chunks = createChunks(texts);
      const translatedChunks: string[][] = texts.map(() => []);
      const detectedLanguages: Array<Set<string>> =
        texts.map(() => new Set());

      for (let start = 0; start < chunks.length; start += CONCURRENCY) {
        const batch = chunks.slice(start, start + CONCURRENCY);
        const results = await Promise.all(
          batch.map((chunk) => translateChunk(chunk, targetLanguage)),
        );

        results.forEach((result, index) => {
          const chunk = batch[index];
          translatedChunks[chunk.inputIndex][chunk.chunkIndex] =
            result.translatedText;

          if (result.detectedLanguage) {
            detectedLanguages[chunk.inputIndex].add(result.detectedLanguage);
          }
        });
      }

      return {
        data: createTranslationResults(
          texts,
          translatedChunks,
          detectedLanguages,
        ),
      };
    } catch (error) {
      console.error("[Translation] LibreTranslate provider failed", {
        errorName: error instanceof Error ? error.name : "UnknownError",
      });
      return {
        error:
          error instanceof Error &&
          (error.message.startsWith("LibreTranslate") ||
            error.message.startsWith("LibreTranslate request"))
            ? error.message
            : "LibreTranslate request failed.",
      };
    }
  }
}

export const libreTranslateProvider = new LibreTranslateProvider();
