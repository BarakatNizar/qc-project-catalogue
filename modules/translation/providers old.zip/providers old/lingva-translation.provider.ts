import "server-only";

import type { TranslationProvider, TranslationProviderName } from "../types/translation.types"; 
import type {
  TranslationLanguage,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

interface LingvaResponse {
  translation?: unknown;
  error?: unknown;
  info?: {
    detectedSource?: unknown;
    detectedSourceLanguage?: unknown;
  };
}

const DEFAULT_BASE_URL = "https://lingva.ml";
const DEFAULT_TIMEOUT_MS = 80_000;
const DEFAULT_CONCURRENCY = 3;
const MAX_TEXT_CODE_POINTS = 3_000;

function getBaseUrl(): string {
  const configured = process.env.LINGVA_BASE_URL?.trim() || DEFAULT_BASE_URL;
  return configured.replace(/\/+$/u, "");
}

function getTimeoutMs(): number {
  const value = Number.parseInt(process.env.LINGVA_TIMEOUT_MS || "", 10);
  return Number.isFinite(value) && value > 0 ? value : DEFAULT_TIMEOUT_MS;
}

function getConcurrency(): number {
  const value = Number.parseInt(
    process.env.LINGVA_MAX_CONCURRENT_REQUESTS || "",
    10,
  );
  return Number.isFinite(value) && value > 0
    ? Math.min(value, 8)
    : DEFAULT_CONCURRENCY;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeLanguageCode(value: unknown): string | null {
  if (typeof value !== "string" || value.trim().length === 0) return null;
  return value.trim().toLowerCase().split(/[-_]/u)[0] || null;
}

function splitText(text: string): string[] {
  const points = Array.from(text);
  if (points.length <= MAX_TEXT_CODE_POINTS) return [text];

  const chunks: string[] = [];
  let start = 0;

  while (start < points.length) {
    let end = Math.min(start + MAX_TEXT_CODE_POINTS, points.length);
    if (end < points.length) {
      const preferredBoundary = start + Math.floor(MAX_TEXT_CODE_POINTS * 0.75);
      for (let cursor = end; cursor > preferredBoundary; cursor -= 1) {
        if (/\s/u.test(points[cursor - 1])) {
          end = cursor;
          break;
        }
      }
    }

    chunks.push(points.slice(start, end).join(""));
    start = end;
  }

  return chunks;
}

function parseLingvaError(status?: number, payload?: unknown): string {
  if (status === 429) return "Lingva rate limit was exceeded. Try again later.";
  if (status === 401 || status === 403) {
    return "Lingva rejected the request. Check the configured Lingva instance.";
  }
  if (status === 404) return "Lingva endpoint or language was not found.";
  if (status !== undefined && status >= 500) {
    return "Lingva is temporarily unavailable.";
  }

  if (isRecord(payload) && typeof payload.error === "string") {
    const message = payload.error.trim();
    if (message.length > 0) {
      // Do not relay arbitrary provider details to clients.
      return "Lingva could not translate the supplied text.";
    }
  }

  return "Lingva translation failed.";
}

async function translateChunk(
  text: string,
  targetLanguage: TranslationLanguage,
): Promise<TranslationResult<TranslationProviderOutput>> {
  const endpoint = `${getBaseUrl()}/api/v1/auto/${targetLanguage}`;

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ query: text }),
      cache: "no-store",
      signal: AbortSignal.timeout(getTimeoutMs()),
    });

    let payload: unknown;
    try {
      payload = await response.json();
    } catch {
      return { error: parseLingvaError(response.status) };
    }

    if (!response.ok) {
      return { error: parseLingvaError(response.status, payload) };
    }

    if (!isRecord(payload)) {
      return { error: "Lingva returned an invalid response." };
    }

    const body = payload as LingvaResponse;
    if (typeof body.error === "string" && body.error.trim().length > 0) {
      return { error: parseLingvaError(response.status, payload) };
    }

    if (typeof body.translation !== "string") {
      return { error: "Lingva response did not contain translated text." };
    }

    const detectedSourceLanguage = normalizeLanguageCode(
      body.info?.detectedSource ?? body.info?.detectedSourceLanguage,
    );

    return {
      data: {
        translatedText: body.translation,
        detectedSourceLanguage,
      },
    };
  } catch (error) {
    const name = error instanceof Error ? error.name : "";
    if (name === "TimeoutError" || name === "AbortError") {
      return { error: "Lingva translation request timed out." };
    }

    console.error("[Translation] Lingva provider request failed", {
      errorName: error instanceof Error ? error.name : "UnknownError",
    });

    return { error: "Lingva is unreachable or the translation request failed." };
  }
}

class LingvaTranslationProvider implements TranslationProvider {
  readonly name: TranslationProviderName="lingva" as const;
  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };

    const chunksByInput = texts.map((text) => splitText(text));
    const tasks = chunksByInput.flatMap((chunks, inputIndex) =>
      chunks.map((text, chunkIndex) => ({ inputIndex, chunkIndex, text })),
    );

    const translatedChunks: string[][] = texts.map(() => []);
    const detectedLanguages: Array<Set<string>> = texts.map(() => new Set());
    const concurrency = getConcurrency();
    let nextTaskIndex = 0;
    let firstError: string | null = null;

    const worker = async (): Promise<void> => {
      while (true) {
        const taskIndex = nextTaskIndex;
        nextTaskIndex += 1;
        if (taskIndex >= tasks.length) return;

        const task = tasks[taskIndex];
        const result = await translateChunk(task.text, targetLanguage);

        if ("error" in result) {
          firstError ??= result.error;
          continue;
        }

        translatedChunks[task.inputIndex][task.chunkIndex] =
          result.data.translatedText;

        if (result.data.detectedSourceLanguage) {
          detectedLanguages[task.inputIndex].add(
            result.data.detectedSourceLanguage,
          );
        }
      }
    };

    await Promise.all(
      Array.from({ length: Math.min(concurrency, tasks.length) }, () => worker()),
    );

    if (firstError) return { error: firstError };

    return {
      data: texts.map((originalText, index) => {
        const detected = [...detectedLanguages[index]];
        return {
          translatedText: translatedChunks[index].join("") || originalText,
          detectedSourceLanguage: detected.length === 1 ? detected[0] : null,
        };
      }),
    };
  }
}

export const lingvaTranslationProvider = new LingvaTranslationProvider();
