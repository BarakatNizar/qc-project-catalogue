import "server-only";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import {
  createByteBatches,
  createChunks,
  createTranslationResults,
  getHttpErrorMessage,
  normalizeLanguageCode,
} from "./translation-provider.utils";

const REQUEST_TIMEOUT = 30_000;
const MAX_BATCH_ITEMS = 50;
const MAX_REQUEST_BYTES = 100_000;

interface DeepLResponse {
  translations?: Array<{
    text?: string;
    detected_source_language?: string;
  }>;
}

function getApiKey(): string | null {
  return process.env.DEEPL_API_KEY || null;
}

function getEndpoint(): string {
  const configured = process.env.DEEPL_API_URL;
  if (configured) return configured.replace(/\/+$/, "");

  return getApiKey()?.endsWith(":fx")
    ? "https://api-free.deepl.com"
    : "https://api.deepl.com";
}

async function translateBatch(
  texts: string[],
  targetLanguage: TranslationLanguage,
): Promise<NonNullable<DeepLResponse["translations"]>> {
  const apiKey = getApiKey();
  if (!apiKey) throw new Error("DEEPL_API_KEY is not configured.");

  const response = await fetch(`${getEndpoint()}/v2/translate`, {
    method: "POST",
    headers: {
      Authorization: `DeepL-Auth-Key ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      text: texts,
      target_lang: targetLanguage.toUpperCase(),
      preserve_formatting: true,
      split_sentences: "nonewlines",
    }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT),
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(getHttpErrorMessage(response.status, "DeepL"));
  }

  const result = (await response.json()) as DeepLResponse;
  if (!Array.isArray(result.translations) ||
      result.translations.length !== texts.length) {
    throw new Error("DeepL returned an incomplete translation response.");
  }
  return result.translations;
}

class DeepLTranslationProvider implements TranslationProvider {
  readonly name = "deepl" as const;

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };
    if (!getApiKey()) return { error: "DEEPL_API_KEY is not configured." };

    try {
      const chunks = createChunks(texts);
      const batches = createByteBatches(
        chunks,
        MAX_BATCH_ITEMS,
        MAX_REQUEST_BYTES,
      );

      const translatedChunks: string[][] = texts.map(() => []);
      const detectedLanguages: Array<Set<string>> =
        texts.map(() => new Set());

      for (const batch of batches) {
        const results = await translateBatch(
          batch.map((chunk) => chunk.text),
          targetLanguage,
        );

        results.forEach((result, index) => {
          const chunk = batch[index];
          if (typeof result.text !== "string") {
            throw new Error("DeepL returned an invalid translation.");
          }

          translatedChunks[chunk.inputIndex][chunk.chunkIndex] = result.text;

          const detected = normalizeLanguageCode(
            result.detected_source_language,
          );
          if (detected) detectedLanguages[chunk.inputIndex].add(detected);
        });
      }

      return {
        data: createTranslationResults(
          texts,
          translatedChunks,
          detectedLanguages,
        ),
      };
    } catch (error) {
      console.error("[Translation] DeepL provider failed", {
        errorName: error instanceof Error ? error.name : "UnknownError",
      });
      return {
        error:
          error instanceof Error &&
          (error.message.startsWith("DeepL") ||
            error.message === "DEEPL_API_KEY is not configured.")
            ? error.message
            : "DeepL translation failed.",
      };
    }
  }
}

export const deeplTranslationProvider = new DeepLTranslationProvider();
