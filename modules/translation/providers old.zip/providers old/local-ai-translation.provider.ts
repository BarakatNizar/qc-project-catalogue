
import "server-only";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import {
  createBatches,
  createChunks,
  createTranslationResults,
  getHttpErrorMessage,
  normalizeLanguageCode,
} from "./translation-provider.utils";

const MAX_REQUEST_CODE_POINTS = 8_000;
const MAX_BATCH_ITEMS = 8;
const DEFAULT_TIMEOUT_MS = 60_000;
const MAX_OUTPUT_TOKENS = 8_192;

interface LocalAIConfig {
  baseUrl: string;
  apiKey: string | null;
  model: string;
  timeoutMs: number;
}

interface LocalAITranslationItem {
  id?: number;
  translatedText?: unknown;
  detectedSourceLanguage?: unknown;
}

interface LocalAIChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string | Array<{ text?: string }> | null;
    };
  }>;
}

function getConfig(): LocalAIConfig | null {
  const baseUrl = process.env.AI_LOCAL_BASE_URL?.trim();
  const model = process.env.AI_LOCAL_MODEL?.trim();

  if (!baseUrl || !model) return null;

  const apiKey = process.env.AI_LOCAL_API_KEY?.trim() || null;

  const configuredTimeout = Number(
    process.env.AI_LOCAL_TIMEOUT_MS,
  );

  const timeoutMs =
    Number.isFinite(configuredTimeout) && configuredTimeout > 0
      ? configuredTimeout
      : DEFAULT_TIMEOUT_MS;

  return {
    baseUrl: baseUrl.replace(/\/+$/, ""),
    apiKey,
    model,
    timeoutMs,
  };
}

function getEndpoint(baseUrl: string): string {
  return `${baseUrl}/chat/completions`;
}

function getOutputContent(
  response: LocalAIChatCompletionResponse,
): string | null {
  const content = response.choices?.[0]?.message?.content;

  if (typeof content === "string") {
    return content;
  }

  if (Array.isArray(content)) {
    const text = content
      .map((part) => part.text ?? "")
      .join("");

    return text || null;
  }

  return null;
}

/**
 * Parses the JSON returned by the local translation model.
 * Handles regular JSON responses and JSON wrapped in Markdown fences.
 */
function parseTranslationResponse(
  content: string,
): LocalAITranslationItem[] | null {
  const cleaned = content
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "")
    .trim();

  const candidates = [cleaned];

  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");

  if (firstBrace !== -1 && lastBrace > firstBrace) {
    candidates.push(cleaned.slice(firstBrace, lastBrace + 1));
  }

  for (const candidate of candidates) {
    try {
      const parsed: unknown = JSON.parse(candidate);

      if (
        typeof parsed !== "object" ||
        parsed === null ||
        !("translations" in parsed) ||
        !Array.isArray(parsed.translations)
      ) {
        continue;
      }

      return parsed.translations as LocalAITranslationItem[];
    } catch {
      // Try the next candidate.
    }
  }

  return null;
}

function getTranslationSystemPrompt(
  targetLanguage: TranslationLanguage,
): string {
  const languageName =
    targetLanguage === "ar" ? "Arabic" : "English";

  return `
You are a professional translation engine.

Translate every provided text into ${languageName}.

Rules:
1. Translate the complete text accurately and naturally.
2. Preserve the original meaning, context, and technical terminology.
3. Preserve Markdown formatting, line breaks, lists, and paragraph structure.
4. Preserve URLs, code snippets, HTML/XML tags, identifiers, and placeholders.
5. Do not translate code, variable names, database fields, or technical identifiers.
6. Do not add explanations, comments, summaries, or additional content.
7. Detect the original language of EACH input independently.
8. Return the detected source language as a two-letter ISO 639-1 code.
9. Return null as detectedSourceLanguage when the source language cannot be determined.
10. Return exactly one JSON object using the requested output structure.

Required output structure:
{
  "translations": [
    {
      "id": 0,
      "translatedText": "Translated text",
      "detectedSourceLanguage": "en"
    }
  ]
}

The translations array must contain exactly one result for every input.
Preserve each input ID exactly.
Return valid JSON only. Do not use Markdown code fences.
`.trim();
}

function calculateMaxOutputTokens(texts: string[]): number {
  const totalCodePoints = texts.reduce(
    (total, text) => total + Array.from(text).length,
    0,
  );

  return Math.min(
    MAX_OUTPUT_TOKENS,
    Math.max(1_024, Math.ceil(totalCodePoints * 1.5)),
  );
}

function parseLocalError(error: unknown): string {
  if (
    error instanceof Error &&
    (error.name === "TimeoutError" || error.name === "AbortError")
  ) {
    return "Local AI Translation request timed out. Increase AI_LOCAL_TIMEOUT_MS or reduce the batch size.";
  }

  return "Local AI Translation failed. Check the local server and model configuration.";
}

class LocalAITranslateProvider implements TranslationProvider {
  readonly name = "ai_local" as const;

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) {
      return { data: [] };
    }

    const config = getConfig();

    if (!config) {
      return {
        error:
          "AI_LOCAL_BASE_URL and AI_LOCAL_MODEL must be configured.",
      };
    }

    try {
      const chunks = createChunks(texts);

      const batches = createBatches(
        chunks,
        MAX_BATCH_ITEMS,
        MAX_REQUEST_CODE_POINTS,
      );

      const translatedChunks: string[][] = texts.map(() => []);
      const detectedLanguages: Array<Set<string>> =
        texts.map(() => new Set());

      const endpoint = getEndpoint(config.baseUrl);

      for (const batch of batches) {
        const inputs = batch.map((chunk, index) => ({
          id: index,
          text: chunk.text,
        }));

        const headers: Record<string, string> = {
          "Content-Type": "application/json",
        };

        if (config.apiKey) {
          headers.Authorization = `Bearer ${config.apiKey}`;
        }

        const response = await fetch(endpoint, {
          method: "POST",
          headers,
          signal: AbortSignal.timeout(config.timeoutMs),
          body: JSON.stringify({
            model: config.model,
            messages: [
              {
                role: "system",
                content: getTranslationSystemPrompt(targetLanguage),
              },
              {
                role: "user",
                content: JSON.stringify({ inputs }),
              },
            ],
            temperature: 0,
            max_tokens: calculateMaxOutputTokens(
              batch.map((chunk) => chunk.text),
            ),
            stream: false,
            response_format: {
              type: "json_object",
            },
          }),
        });

        if (!response.ok) {
          return {
            error: getHttpErrorMessage(
              response.status,
              "Local AI Translation",
            ),
          };
        }

        const responseBody =
          (await response.json()) as LocalAIChatCompletionResponse;

        const content = getOutputContent(responseBody);

        if (!content) {
          return {
            error:
              "Local AI Translation returned an empty response.",
          };
        }

        const translations = parseTranslationResponse(content);

        if (
          !translations ||
          translations.length !== batch.length
        ) {
          return {
            error:
              "Local AI Translation returned an invalid or incomplete response.",
          };
        }

        const translationsById = new Map<number, LocalAITranslationItem>();

        for (const translation of translations) {
          if (
            typeof translation.id !== "number" ||
            translationsById.has(translation.id)
          ) {
            return {
              error:
                "Local AI Translation returned invalid translation IDs.",
            };
          }

          translationsById.set(translation.id, translation);
        }

        for (let index = 0; index < batch.length; index += 1) {
          const chunk = batch[index];
          const translation = translationsById.get(index);

          if (
            !translation ||
            typeof translation.translatedText !== "string"
          ) {
            return {
              error:
                "Local AI Translation returned an incomplete translation.",
            };
          }

          translatedChunks[chunk.inputIndex][chunk.chunkIndex] =
            translation.translatedText;

          const detected = normalizeLanguageCode(
            typeof translation.detectedSourceLanguage === "string"
              ? translation.detectedSourceLanguage
              : null,
          );

          if (detected) {
            detectedLanguages[chunk.inputIndex].add(detected);
          }
        }
      }

      return {
        data: createTranslationResults(
          texts,
          translatedChunks,
          detectedLanguages,
        ),
      };
    } catch (error) {
      console.error("[Translation] Local AI provider failed", {
        errorName:
          error instanceof Error ? error.name : "UnknownError",
      });

      return {
        error: parseLocalError(error),
      };
    }
  }
}

export const localAITranslateProvider =
  new LocalAITranslateProvider();
