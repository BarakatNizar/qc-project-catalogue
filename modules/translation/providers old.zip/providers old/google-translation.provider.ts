//@/modules/translation/providers/google-translation.provider.ts"
import "server-only";

import { TranslationServiceClient } from "@google-cloud/translate";

import type {
  TranslationLanguage,
  TranslationProvider,
  TranslationProviderOutput,
  TranslationResult,
} from "../types/translation.types";

import {
  createBatches,
  createChunks,
  createTranslationResults,
  normalizeLanguageCode,
} from "./translation-provider.utils";

const MAX_REQUEST_CODE_POINTS = 25_000;
const MAX_BATCH_ITEMS = 128;

let client: TranslationServiceClient | null = null;

function getClient(): TranslationServiceClient {
  if (!client) client = new TranslationServiceClient();
  return client;
}

function getParent(): string | null {
  const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
  if (!projectId) return null;

  const location =
    process.env.GOOGLE_CLOUD_TRANSLATION_LOCATION || "global";

  return `projects/${projectId}/locations/${location}`;
}

function parseGoogleError(error: unknown): string {
  const code =
    typeof error === "object" && error !== null && "code" in error
      ? Number((error as { code?: unknown }).code)
      : undefined;

  if (code === 7 || code === 16) {
    return "Google Translation authentication or permission failed.";
  }
  if (code === 8 || code === 429) {
    return "Google Translation quota or rate limit was exceeded.";
  }
  if (code === 3) {
    return "Google Translation rejected the request. Check text size and language configuration.";
  }
  if (code === 4 || code === 14) {
    return "Google Translation is temporarily unavailable or timed out.";
  }
  return "Google Translation failed.";
}

class GoogleTranslationProvider implements TranslationProvider {
  readonly name = "google" as const;

  async translateMany(
    texts: string[],
    targetLanguage: TranslationLanguage,
  ): Promise<TranslationResult<TranslationProviderOutput[]>> {
    if (texts.length === 0) return { data: [] };

    const parent = getParent();
    if (!parent) {
      return { error: "GOOGLE_CLOUD_PROJECT_ID is not configured." };
    }

    try {
      const chunks = createChunks(texts);
      const batches = createBatches(
        chunks,
        MAX_BATCH_ITEMS,
        MAX_REQUEST_CODE_POINTS,
      );

      const translatedChunks: string[][] = texts.map(() => []);
      const detectedLanguages: Array<Set<string>> =
        texts.map(() => new Set());

      for (const batch of batches) {
        const [response] = await getClient().translateText(
          {
            parent,
            contents: batch.map((chunk) => chunk.text),
            mimeType: "text/plain",
            targetLanguageCode: targetLanguage,
          },
          { timeout: 30_000 },
        );

        const translations = response.translations ?? [];
        if (translations.length !== batch.length) {
          return {
            error: "Google Translation returned an incomplete response.",
          };
        }

        translations.forEach((translation, index) => {
          const chunk = batch[index];
          translatedChunks[chunk.inputIndex][chunk.chunkIndex] =
            translation.translatedText || chunk.text;

          const detected = normalizeLanguageCode(
            translation.detectedLanguageCode,
          );
          if (detected) detectedLanguages[chunk.inputIndex].add(detected);
        });
      }

      return {
        data: createTranslationResults(
          texts,
          translatedChunks,
          detectedLanguages,
        ),
      };
    } catch (error) {
      console.error("[Translation] Google provider failed", {
        errorName: error instanceof Error ? error.name : "UnknownError",
      });
      return { error: parseGoogleError(error) };
    }
  }
}

export const googleTranslationProvider = new GoogleTranslationProvider();

// import "server-only";

// import { TranslationServiceClient } from "@google-cloud/translate";

// import type {
//   TranslationLanguage,
//   TranslationResult,
//   TranslationProviderOutput,
// } from "../types/translation.types";


// // export type TranslationLanguage = "en" | "ar";
// // export type TranslationResult<T> =
// //   | { data: T }
// //   | { error: string };
// // export interface TranslationProviderOutput {
// //   translatedText: string;
// //   detectedSourceLanguage: string | null;
// // }


// export interface TranslationProvider {
//   translateMany(
//     texts: string[],
//     targetLanguage: TranslationLanguage,
//   ): Promise<TranslationResult<TranslationProviderOutput[]>>;
// }

// const MAX_CONTENT_CODE_POINTS = 1_000;
// const MAX_REQUEST_CODE_POINTS = 25_000;

// interface TextChunk {
//   inputIndex: number;
//   chunkIndex: number;
//   text: string;
// }

// let client: TranslationServiceClient | null = null;

// function getClient(): TranslationServiceClient {
//   if (!client) {
//     client = new TranslationServiceClient();
//   }

//   return client;
// }

// function getParent(): string | null {
//   const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
//   if (!projectId) return null;

//   const location =
//     process.env.GOOGLE_CLOUD_TRANSLATION_LOCATION || "global";

//   return `projects/${projectId}/locations/${location}`;
// }

// /** Splits by Unicode code points and keeps all original whitespace. */
// function splitText(text: string): string[] {
//   const codePoints = Array.from(text);
//   if (codePoints.length <= MAX_CONTENT_CODE_POINTS) return [text];

//   const chunks: string[] = [];
//   let start = 0;

//   while (start < codePoints.length) {
//     let end = Math.min(start + MAX_CONTENT_CODE_POINTS, codePoints.length);

//     if (end < codePoints.length) {
//       const preferredBoundary = start + Math.floor(MAX_CONTENT_CODE_POINTS * 0.75);

//       for (let cursor = end; cursor > preferredBoundary; cursor -= 1) {
//         if (/\s/u.test(codePoints[cursor - 1])) {
//           end = cursor;
//           break;
//         }
//       }
//     }

//     chunks.push(codePoints.slice(start, end).join(""));
//     start = end;
//   }

//   return chunks;
// }

// function createBatches(chunks: TextChunk[]): TextChunk[][] {
//   const batches: TextChunk[][] = [];
//   let current: TextChunk[] = [];
//   let currentCodePoints = 0;

//   for (const chunk of chunks) {
//     const length = Array.from(chunk.text).length;

//     if (
//       current.length > 0 &&
//       currentCodePoints + length > MAX_REQUEST_CODE_POINTS
//     ) {
//       batches.push(current);
//       current = [];
//       currentCodePoints = 0;
//     }

//     current.push(chunk);
//     currentCodePoints += length;
//   }

//   if (current.length > 0) batches.push(current);
//   return batches;
// }

// function normalizeLanguageCode(code: string): string {
//   return code.toLowerCase().split("-")[0];
// }

// function parseGoogleTranslationError(error: unknown): string {
//   const code =
//     typeof error === "object" && error !== null && "code" in error
//       ? Number((error as { code?: unknown }).code)
//       : undefined;

//   if (code === 7 || code === 16) {
//     return "Google Translation authentication or permission failed. Check the server credentials and API permissions.";
//   }

//   if (code === 8 || code === 429) {
//     return "Google Translation quota or rate limit was exceeded.";
//   }

//   if (code === 3) {
//     return "Google Translation rejected the request. Check the text size and language configuration.";
//   }

//   if (code === 4 || code === 14) {
//     return "Google Translation is temporarily unavailable or timed out.";
//   }

//   return "Google Translation failed. The original project data will be used.";
// }

// class GoogleTranslationProvider implements TranslationProvider {
//   async translateMany(
//     texts: string[],
//     targetLanguage: TranslationLanguage,
//   ): Promise<TranslationResult<TranslationProviderOutput[]>> {
//     if (texts.length === 0) return { data: [] };

//     const parent = getParent();
//     if (!parent) {
//       return { error: "GOOGLE_CLOUD_PROJECT_ID is not configured." };
//     }

//     try {
//       const translationClient = getClient();
//       const chunks: TextChunk[] = [];
//       const chunksPerInput: string[][] = texts.map((text) => splitText(text));

//       chunksPerInput.forEach((inputChunks, inputIndex) => {
//         inputChunks.forEach((text, chunkIndex) => {
//           chunks.push({ inputIndex, chunkIndex, text });
//         });
//       });

//       const batches = createBatches(chunks);
//       const translatedChunks: string[][] = texts.map(() => []);
//       const detectedLanguages: Array<Set<string>> = texts.map(() => new Set());

//       for (const batch of batches) {
//         const [response] = await translationClient.translateText(
//           {
//             parent,
//             contents: batch.map((chunk) => chunk.text),
//             mimeType: "text/plain",
//             targetLanguageCode: targetLanguage,
//             // sourceLanguageCode is intentionally omitted for automatic detection.
//           },
//           { timeout: 30_000 },
//         );

//         const translations = response.translations ?? [];
//         if (translations.length !== batch.length) {
//           return {
//             error: "Google Translation returned an incomplete response.",
//           };
//         }

//         translations.forEach((translation: { translatedText?: string | null; detectedLanguageCode?: string | null }, index: number) => {
//           const chunk = batch[index];
//           translatedChunks[chunk.inputIndex][chunk.chunkIndex] =
//             translation.translatedText || chunk.text;

//           if (translation.detectedLanguageCode) {
//             detectedLanguages[chunk.inputIndex].add(
//               normalizeLanguageCode(translation.detectedLanguageCode),
//             );
//           }
//         });
//       }

//       return {
//         data: texts.map((originalText, index) => {
//           const languages = [...detectedLanguages[index]];

//           return {
//             translatedText:
//               translatedChunks[index].join("") || originalText,
//             detectedSourceLanguage:
//               languages.length === 1 ? languages[0] : null,
//           };
//         }),
//       };
//     } catch (error) {
//       console.error("[Translation] Google provider request failed", {
//         errorName: error instanceof Error ? error.name : "UnknownError",
//       });

//       return { error: parseGoogleTranslationError(error) };
//     }
//   }
// }

// export const googleTranslationProvider = new GoogleTranslationProvider();
