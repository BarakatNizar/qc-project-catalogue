//@/modules/translation/providers/translation-provider.utils.ts
import type {
  TranslationProviderOutput,
} from "../types/translation.types";

export interface TextChunk {
  inputIndex: number;
  chunkIndex: number;
  text: string;
}

/**
 * Splits text by Unicode code points and preserves all original whitespace.
 * The preferred split point is a whitespace boundary near the end of a chunk.
 */
export function splitText(
  text: string,
  maxCodePoints = 1_000,
): string[] {
  const codePoints = Array.from(text);

  if (codePoints.length <= maxCodePoints) return [text];

  const chunks: string[] = [];
  let start = 0;

  while (start < codePoints.length) {
    let end = Math.min(start + maxCodePoints, codePoints.length);

    if (end < codePoints.length) {
      const preferredBoundary =
        start + Math.floor(maxCodePoints * 0.75);

      for (let cursor = end; cursor > preferredBoundary; cursor -= 1) {
        if (/\s/u.test(codePoints[cursor - 1])) {
          end = cursor;
          break;
        }
      }
    }

    chunks.push(codePoints.slice(start, end).join(""));
    start = end;
  }

  return chunks;
}

export function createChunks(texts: string[]): TextChunk[] {
  const chunks: TextChunk[] = [];

  texts.forEach((text, inputIndex) => {
    splitText(text).forEach((chunk, chunkIndex) => {
      chunks.push({ inputIndex, chunkIndex, text: chunk });
    });
  });

  return chunks;
}

export function createBatches(
  chunks: TextChunk[],
  maxItems: number,
  maxCharacters: number,
): TextChunk[][] {
  const batches: TextChunk[][] = [];
  let current: TextChunk[] = [];
  let currentCharacters = 0;

  for (const chunk of chunks) {
    const length = Array.from(chunk.text).length;

    if (
      current.length > 0 &&
      (current.length >= maxItems ||
        currentCharacters + length > maxCharacters)
    ) {
      batches.push(current);
      current = [];
      currentCharacters = 0;
    }

    current.push(chunk);
    currentCharacters += length;
  }

  if (current.length > 0) batches.push(current);
  return batches;
}

export function createByteBatches(
  chunks: TextChunk[],
  maxItems: number,
  maxBytes: number,
): TextChunk[][] {
  const encoder = new TextEncoder();
  const batches: TextChunk[][] = [];
  let current: TextChunk[] = [];
  let currentBytes = 0;

  for (const chunk of chunks) {
    const bytes = encoder.encode(chunk.text).byteLength;

    if (bytes > maxBytes) {
      throw new Error("A translation chunk exceeds the request byte limit.");
    }

    if (
      current.length > 0 &&
      (current.length >= maxItems || currentBytes + bytes > maxBytes)
    ) {
      batches.push(current);
      current = [];
      currentBytes = 0;
    }

    current.push(chunk);
    currentBytes += bytes;
  }

  if (current.length > 0) batches.push(current);
  return batches;
}

export function normalizeLanguageCode(
  code: string | null | undefined,
): string | null {
  return code ? code.toLowerCase().split("-")[0] : null;
}

export function createTranslationResults(
  texts: string[],
  translatedChunks: string[][],
  detectedLanguages: Array<Set<string>>,
): TranslationProviderOutput[] {
  return texts.map((originalText, index) => {
    const languages = [...detectedLanguages[index]];

    return {
      translatedText:
        translatedChunks[index].join("") || originalText,
      detectedSourceLanguage:
        languages.length === 1 ? languages[0] : null,
    };
  });
}

export function getHttpErrorMessage(
  status: number,
  provider: string,
): string {
  if (status === 401 || status === 403) {
    return `${provider} authentication or permission failed. Check API credentials and permissions.`;
  }
  if (status === 413) {
    return `${provider} rejected the request because its payload is too large.`;
  }
  if (status === 429) {
    return `${provider} quota or rate limit was exceeded.`;
  }
  if (status === 400 || status === 422) {
    return `${provider} rejected the request. Check text size and language configuration.`;
  }
  if (status === 408 || status === 504) {
    return `${provider} request timed out.`;
  }
  if (status >= 500) {
    return `${provider} is temporarily unavailable.`;
  }
  return `${provider} request failed with HTTP status ${status}.`;
}

export function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Unknown error.";
}
